package Main;
import vista.Diseño;

public class Registro {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(()-> new Diseño().setVisible(true));
    }
    
}
