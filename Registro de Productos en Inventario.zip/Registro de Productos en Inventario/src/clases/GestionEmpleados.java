package clases;


public class GestionEmpleados {
    
   //Atributos
    private Empleado[] empleado;
    private int contador;
    
    //Constructor
    public GestionEmpleados(){
        empleado = new Empleado[100];
        contador = 0;
    
    }
    
    //Método agregar un empleado   
    public boolean agregarEmpleado(Empleado nuevo){
        if(contador < empleado.length){
            empleado[contador] = nuevo;
            contador++;
            return true;
        }
        return false;
    }
    
    //metodo para obtener empleado
    public Empleado[] obtenerEmpleado(){
        Empleado[] resultado = new Empleado[contador];
        for(int i=0; i < contador; i++ ){
        resultado[i]  = empleado[i];
        }
        return resultado;
    }
     
    
    //metodo para limpiar
    public boolean eliminarEmpleado(String id){
        for(int i=0; i<contador;i++){
            if(empleado[i].getId().equalsIgnoreCase(id)){
                //mover los elementos restantes a una posicion hacia arriba
                for(int j = i; j<contador-1; j++){
                empleado[j] = empleado[j+1];
                }
                empleado[contador-1] = null;
                contador --;
                return true;
            }
        }
        return false; //No encontrado
    }
}
    
    

