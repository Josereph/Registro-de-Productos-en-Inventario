package clases;


public class Gestion_Registros {
    
   //Atributos
    private Registro_Utilidades[] empleado;
    private int contador;
    
    //Constructor
    public Gestion_Registros(){
        empleado = new Registro_Utilidades[100];
        contador = 0;
    
    }
    
    //Método agregar un empleado   
    public boolean agregarEmpleado(Registro_Utilidades nuevo){
        if(contador < empleado.length){
            empleado[contador] = nuevo;
            contador++;
            return true;
        }
        return false;
    }
    
    //metodo para obtener empleado
    public Registro_Utilidades[] obtenerEmpleado(){
        Registro_Utilidades[] resultado = new Registro_Utilidades[contador];
        for(int i=0; i < contador; i++ ){
        resultado[i]  = empleado[i];
        }
        return resultado;
    }
     
    
    //metodo para limpiar
    public boolean eliminarEmpleado(String id){
        for(int i=0; i<contador;i++){
            if(empleado[i].getId().equalsIgnoreCase(id)){
                //mover los elementos restantes a una posicion hacia arriba
                for(int j = i; j<contador-1; j++){
                empleado[j] = empleado[j+1];
                }
                empleado[contador-1] = null;
                contador --;
                return true;
            }
        }
        return false; //No encontrado
    }
}
    
    

