package clases;


public class Registro_Utilidades {

    
        //Atributos
    public String id;
    public String nombre;
    public String dui;
    public int edad;
    public String genero;
    public String cargo;
    public String profesion;
    public String nacimiento;
    public double salario;

    public Registro_Utilidades(String id, String nombre, String dui, int edad, String genero, String cargo, String profesion, String nacimiento, double salario) {
        this.id = id;
        this.nombre = nombre;
        this.dui = dui;
        this.edad = edad;
        this.genero = genero;
        this.cargo = cargo;
        this.profesion = profesion;
        this.nacimiento = nacimiento;
        this.salario = salario;
    }

    
    
    
    
    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDui() {
        return dui;
    }

    public int getEdad() {
        return edad;
    }

    public String getGenero() {
        return genero;
    }

    public String getCargo() {
        return cargo;
    }

    public String getProfesion() {
        return profesion;
    }

    public String getNacimiento() {
        return nacimiento;
    }

    public double getSalario() {
        return salario;
    }
    
}
