package javaapplication1;
import vista.Diseño;

public class empleados {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(()-> new Diseño().setVisible(true));
    }
    
}
