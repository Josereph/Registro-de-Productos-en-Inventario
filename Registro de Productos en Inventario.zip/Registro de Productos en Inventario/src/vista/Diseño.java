package vista;

import clases.Registro_Utilidades;
import clases.Gestion_Registros;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


 
public class Diseño extends javax.swing.JFrame {
Gestion_Registros gestion = new Gestion_Registros();
private boolean modoEdicion = false;
private int filaEditando = -1;

    public Diseño() {
        initComponents();
        setLocationRelativeTo(null);
        SpinnerNumberModel modelo = new SpinnerNumberModel(1,1,10000,1);
        txtedad.setModel(modelo); //Cantidad
        javax.swing.ButtonGroup grupoGenero = new javax.swing.ButtonGroup();
        grupoGenero.add(checkmasculino); // Buen Estado
        grupoGenero.add(checkfemenino); // Dañado
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        dgvregistro = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        txtid = new javax.swing.JTextField();
        txtnombre = new javax.swing.JTextField();
        txtdui = new javax.swing.JTextField();
        txtedad = new javax.swing.JSpinner();
        checkmasculino = new javax.swing.JRadioButton();
        checkfemenino = new javax.swing.JRadioButton();
        comboCargo = new javax.swing.JComboBox<>();
        txtsalario = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtfecha = new com.toedter.calendar.JDateChooser();
        jScrollPane3 = new javax.swing.JScrollPane();
        listaprofesion = new javax.swing.JList<>();
        jPanel4 = new javax.swing.JPanel();
        btnguardar = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        btneditar = new javax.swing.JButton();
        btnborrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Registro de Productos en Inventario");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 896, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        dgvregistro.setBackground(new java.awt.Color(255, 255, 255));
        dgvregistro.setForeground(new java.awt.Color(0, 0, 0));
        dgvregistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nombre", "Observaciones", "Cantidad", "Estado", "Unidad de Medidad", "Ubicacion", "Fecha de Registro", "Lote"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        dgvregistro.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                dgvregistroComponentHidden(evt);
            }
        });
        jScrollPane2.setViewportView(dgvregistro);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));

        txtid.setBackground(new java.awt.Color(255, 255, 255));
        txtid.setForeground(new java.awt.Color(0, 0, 0));
        txtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidActionPerformed(evt);
            }
        });

        txtnombre.setBackground(new java.awt.Color(255, 255, 255));
        txtnombre.setForeground(new java.awt.Color(0, 0, 0));
        txtnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreActionPerformed(evt);
            }
        });

        txtdui.setBackground(new java.awt.Color(255, 255, 255));
        txtdui.setForeground(new java.awt.Color(0, 0, 0));

        txtedad.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        checkmasculino.setBackground(new java.awt.Color(153, 204, 255));
        checkmasculino.setForeground(new java.awt.Color(0, 0, 0));
        checkmasculino.setText("Buen estado");
        checkmasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkmasculinoActionPerformed(evt);
            }
        });

        checkfemenino.setBackground(new java.awt.Color(153, 204, 255));
        checkfemenino.setForeground(new java.awt.Color(0, 0, 0));
        checkfemenino.setText("Dañado");

        comboCargo.setBackground(new java.awt.Color(255, 255, 255));
        comboCargo.setForeground(new java.awt.Color(0, 0, 0));
        comboCargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Unidad", "Pieza", "Ítem", "Caja", "Gramo", "Kilogramo", "Tonelada", "Libra", "Onza", "Mililitro", "Litro", "Galón", "Barril", "Centímetro cúbico", "Metro cúbico", "Milímetro", "Centímetro", "Metro", "Kilómetro", "Pulgada", "Pie", "Yarda", "Metro lineal", "Rollo", "Paquete", "Bolsa", "Saco", "Pallet", "Tarima", "Tambor", "Unidad internacional", "Docena", "Media docena", "Set", "Kit", "Tableta", "Cápsula", "Quintal", "Arroba" }));

        txtsalario.setBackground(new java.awt.Color(255, 255, 255));
        txtsalario.setForeground(new java.awt.Color(0, 0, 0));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Código de Entrada");

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Nombre de Producto:");

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Observaciones:");

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Estado:");

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Cantidad:");

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Unidad de Medida:");

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Ubicación de Almacenamiento:");

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Fecha de Recibido:");

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("N° Lote:");

        txtfecha.setBackground(new java.awt.Color(255, 255, 255));
        txtfecha.setForeground(new java.awt.Color(0, 0, 0));

        listaprofesion.setBackground(new java.awt.Color(255, 255, 255));
        listaprofesion.setForeground(new java.awt.Color(0, 0, 0));
        listaprofesion.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Bodega Principal", "Bodega Secundaria", "Bodega de Retiro", "Bodega de Cuarentena", "Bodega de Devoluciones", "Bodega de Materia Prima", "Bodega de Producto Terminado" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listaprofesion);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtfecha, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtnombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                    .addComponent(txtid, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                    .addComponent(txtedad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(checkmasculino)
                        .addGap(18, 18, 18)
                        .addComponent(checkfemenino))
                    .addComponent(comboCargo, javax.swing.GroupLayout.Alignment.LEADING, 0, 215, Short.MAX_VALUE)
                    .addComponent(txtsalario))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtdui, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtdui, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addGap(7, 7, 7)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(checkmasculino)
                                    .addComponent(jLabel5)
                                    .addComponent(checkfemenino))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(comboCargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(txtfecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(txtsalario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18))
        );

        jPanel4.setBackground(new java.awt.Color(153, 204, 255));

        btnguardar.setBackground(new java.awt.Color(255, 255, 255));
        btnguardar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btnguardar.setForeground(new java.awt.Color(0, 0, 0));
        btnguardar.setText("Guardar");
        btnguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarActionPerformed(evt);
            }
        });

        btnlimpiar.setBackground(new java.awt.Color(255, 255, 255));
        btnlimpiar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btnlimpiar.setForeground(new java.awt.Color(0, 0, 0));
        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });

        btneditar.setBackground(new java.awt.Color(255, 255, 255));
        btneditar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btneditar.setForeground(new java.awt.Color(0, 0, 0));
        btneditar.setText("Editar");
        btneditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditarActionPerformed(evt);
            }
        });

        btnborrar.setBackground(new java.awt.Color(255, 255, 255));
        btnborrar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btnborrar.setForeground(new java.awt.Color(0, 0, 0));
        btnborrar.setText("Borrar");
        btnborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnborrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(btnguardar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnlimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btneditar, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnborrar, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnguardar, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(btnlimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnborrar, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(btneditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    private boolean actualizarEmpleadoEnGestion(String id, String nombre, String dui, int edad, 
                                           String genero, String cargo, String profesion, 
                                           String nacimiento, double salario) {
    // Obtener todos los empleados
    Registro_Utilidades[] empleados = gestion.obtenerEmpleado();
    
    // Buscar y actualizar el empleado por ID
    for(int i = 0; i < empleados.length; i++) {
        if(empleados[i] != null && empleados[i].getId().equals(id)) {
            // Como los campos son públicos en tu clase Registro_Utilidades, puedes modificarlos directamente
            empleados[i].nombre = nombre; 
            empleados[i].dui = dui;
            empleados[i].edad = edad;
            empleados[i].genero = genero;
            empleados[i].cargo = cargo;
            empleados[i].profesion = profesion;
            empleados[i].nacimiento = nacimiento;
            empleados[i].salario = salario;
            return true;
        }
    }
    return false;
    }
    
    private void limpiarCampos() {
    txtid.setText("");
    txtnombre.setText("");
    txtdui.setText("");
    txtedad.setValue(18);
    checkmasculino.setSelected(false);
    checkfemenino.setSelected(false);
    comboCargo.setSelectedIndex(0);
    listaprofesion.clearSelection();
    txtfecha.setDate(null);
    txtsalario.setText("");
    }
    
    
    
    private void btnguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarActionPerformed
     try {
        String id = txtid.getText();
        String nombre = txtnombre.getText();
        String dui = txtdui.getText();
        int edad = (int) txtedad.getValue();
        String genero = checkmasculino.isSelected() ? "Buen Estado" : "Dañado";
        String cargo = comboCargo.getSelectedItem().toString();
        String profesion = listaprofesion.getSelectedValue();
        String nacimiento = ((JTextField)txtfecha.getDateEditor().getUiComponent()).getText();
        Double salario = Double.parseDouble(txtsalario.getText());

        DefaultTableModel modelo = (DefaultTableModel) dgvregistro.getModel();
        
        if(modoEdicion) {
            modelo.setValueAt(id, filaEditando, 0);
            modelo.setValueAt(nombre, filaEditando, 1);
            modelo.setValueAt(dui, filaEditando, 2);
            modelo.setValueAt(edad, filaEditando, 3);
            modelo.setValueAt(genero, filaEditando, 4);
            modelo.setValueAt(cargo, filaEditando, 5);
            modelo.setValueAt(profesion, filaEditando, 6);
            modelo.setValueAt(nacimiento, filaEditando, 7);
            modelo.setValueAt(salario, filaEditando, 8);
            
            if(actualizarEmpleadoEnGestion(id, nombre, dui, edad, genero, cargo, profesion, nacimiento, salario)) {
                JOptionPane.showMessageDialog(this, "Registro actualizado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el empleado.");
            }
            
            modoEdicion = false;
            filaEditando = -1;
            btnguardar.setText("Guardar 📼");
            
        } else {
            modelo.addRow(new Object[]{id, nombre, dui, edad, genero, cargo, profesion, nacimiento, salario});
            
            Registro_Utilidades nuevo = new Registro_Utilidades(id, nombre, dui, edad, genero, cargo, profesion, nacimiento, salario);
            
            if(gestion.agregarEmpleado(nuevo)){
                JOptionPane.showMessageDialog(this, "Registro guardado correctamente");    
            } else{
                JOptionPane.showMessageDialog(this, "No se pudo guardar el registro");    
            }
        }
        
        limpiarCampos();
        
    } catch(Exception e) {
        JOptionPane.showMessageDialog(this, "Error! Verifique que todos los campos estén llenos correctamente.");
    }
    
     
     dgvregistro();
    }//GEN-LAST:event_btnguardarActionPerformed

    private void txtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidActionPerformed

    private void txtnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreActionPerformed

    private void checkmasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkmasculinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkmasculinoActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
     limpiarCampos();
    
    // Si estaba en modo edición, salir del modo edición
    if(modoEdicion) {
        modoEdicion = false;
        filaEditando = -1;
        btnguardar.setText("Guardar 📼");
        JOptionPane.showMessageDialog(this, "Modo edición cancelado");
    }
    }//GEN-LAST:event_btnlimpiarActionPerformed

    
    
    
    
    
    private void btneditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditarActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = dgvregistro.getSelectedRow();
    
    if(filaSeleccionada >= 0) {
        // Entrar en modo edición
        modoEdicion = true;
        filaEditando = filaSeleccionada;
        
        // Cargar los datos del empleado seleccionado en los campos
        txtid.setText(dgvregistro.getValueAt(filaSeleccionada, 0).toString());
        txtnombre.setText(dgvregistro.getValueAt(filaSeleccionada, 1).toString());
        txtdui.setText(dgvregistro.getValueAt(filaSeleccionada, 2).toString());
        txtedad.setValue(Integer.parseInt(dgvregistro.getValueAt(filaSeleccionada, 3).toString()));
        
        // Seleccionar el género correcto
        String genero = dgvregistro.getValueAt(filaSeleccionada, 4).toString();
        if(genero.equals("Buen Estado")) {
            checkmasculino.setSelected(true);
            checkfemenino.setSelected(false);
        } else {
            checkfemenino.setSelected(true);
            checkmasculino.setSelected(false);
        }
        
        // Seleccionar el cargo
        String cargo = dgvregistro.getValueAt(filaSeleccionada, 5).toString();
        comboCargo.setSelectedItem(cargo);
        
        // Seleccionar la profesión
        String profesion = dgvregistro.getValueAt(filaSeleccionada, 6).toString();
        listaprofesion.setSelectedValue(profesion, true);
        
        // Cargar fecha (si no es nula)
        String fecha = dgvregistro.getValueAt(filaSeleccionada, 7).toString();
        ((JTextField)txtfecha.getDateEditor().getUiComponent()).setText(fecha);
        
        // Cargar salario
        txtsalario.setText(dgvregistro.getValueAt(filaSeleccionada, 8).toString());
        
        // Cambiar el texto del botón guardar
        btnguardar.setText("Actualizar");
        
        JOptionPane.showMessageDialog(this, "Registro cargado para edición. Modifique los datos y presione 'Actualizar'");
        
    } else {
        JOptionPane.showMessageDialog(this, "Por favor seleccione un empleado de la tabla para editar");
    }
        
        
        dgvregistro();
        
    }//GEN-LAST:event_btneditarActionPerformed

    
    
    
    
    
    private void btnborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnborrarActionPerformed
        // TODO add your handling code here:
    int filaseleccionada = dgvregistro.getSelectedRow();
    DefaultTableModel modelo = (DefaultTableModel) dgvregistro.getModel();
        
    
        if(filaseleccionada>=0){
            String id = dgvregistro.getValueAt(filaseleccionada, 0).toString();
            int confirmar = JOptionPane.showConfirmDialog(this, 
                    "Estas Segur@ que quieres eliminar el registro con ID" + id + "?", "Confirmar eliminacion", JOptionPane.YES_NO_OPTION);
                    
            if(confirmar==JOptionPane.YES_OPTION){
                boolean eliminado = gestion.eliminarEmpleado(id);
                
                if(eliminado){
                    JOptionPane.showConfirmDialog(this, "El registro se eliminó correctamente");
                     modelo.removeRow(filaseleccionada);
                }else{
                    JOptionPane.showConfirmDialog(this, "No se pudo eliminar!");
                }
            }
        }
        dgvregistro();
    }//GEN-LAST:event_btnborrarActionPerformed

    
    
    
    
    private void dgvregistroComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_dgvregistroComponentHidden
        // TODO add your handling code here:
    }//GEN-LAST:event_dgvregistroComponentHidden

    
    
    
    private void dgvregistro(){
    DefaultTableModel modelo = (DefaultTableModel) dgvregistro.getModel();
    
    modelo.setRowCount(0);
    for(Registro_Utilidades emp : gestion.obtenerEmpleado()){
        Object[] fila = {
        emp.getId(),
        emp.getNombre(),
        emp.getDui(),
        emp.getEdad(),
        emp.getGenero(),
        emp.getCargo(),
        emp.getProfesion(),
        emp.getNacimiento(),
        emp.getSalario(),
                };
        modelo.addRow(fila);
            }
        }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Diseño().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnborrar;
    private javax.swing.JButton btneditar;
    private javax.swing.JButton btnguardar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JRadioButton checkfemenino;
    private javax.swing.JRadioButton checkmasculino;
    private javax.swing.JComboBox<String> comboCargo;
    private javax.swing.JTable dgvregistro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JList<String> listaprofesion;
    private javax.swing.JTextField txtdui;
    private javax.swing.JSpinner txtedad;
    private com.toedter.calendar.JDateChooser txtfecha;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtsalario;
    // End of variables declaration//GEN-END:variables
}
