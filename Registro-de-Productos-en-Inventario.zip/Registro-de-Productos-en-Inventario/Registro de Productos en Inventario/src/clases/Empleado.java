package clases;

public class Empleado {
    
    // Atributos
    private String codigoEntrada;
    private String nombreProducto;
    private String estado;
    private int cantidad;
    private String fechaRecibido;
    private String unidadMedida;
    private int nLote;
    private String ubicacion;
    private String observaciones; // Cambié a String porque no tiene sentido que sean double

    // Constructor
    public Empleado(String codigoEntrada, String nombreProducto, String estado, int cantidad, 
                    String fechaRecibido, String unidadMedida, int nLote, String ubicacion, String observaciones) {
        this.codigoEntrada = codigoEntrada;
        this.nombreProducto = nombreProducto;
        this.estado = estado;
        this.cantidad = cantidad;
        this.fechaRecibido = fechaRecibido;
        this.unidadMedida = unidadMedida;
        this.nLote = nLote;
        this.ubicacion = ubicacion;
        this.observaciones = observaciones;
    }

    // Getters
    public String getCodigoEntrada() {
        return codigoEntrada;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public String getEstado() {
        return estado;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getFechaRecibido() {
        return fechaRecibido;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public int getNLote() {
        return nLote;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getObservaciones() {
        return observaciones;
    }
}
