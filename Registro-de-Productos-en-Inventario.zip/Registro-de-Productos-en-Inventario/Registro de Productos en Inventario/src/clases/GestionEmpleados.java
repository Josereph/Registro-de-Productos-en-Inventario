package clases;

public class GestionEmpleados {
    
   // Atributos
    private Empleado[] empleados;
    private int contador;
    
    // Constructor
    public GestionEmpleados() {
        empleados = new Empleado[100];
        contador = 0;
    }
    
    // Método para agregar un empleado   
    public boolean agregarEmpleado(Empleado nuevo) {
        if (contador < empleados.length) {
            empleados[contador] = nuevo;
            contador++;
            return true;
        }
        return false;
    }
    
    // Método para obtener todos los empleados
    public Empleado[] obtenerEmpleados() {
        Empleado[] resultado = new Empleado[contador];
        for (int i = 0; i < contador; i++) {
            resultado[i] = empleados[i];
        }
        return resultado;
    }
     
    // Método para eliminar empleado por su códigoEntrada
    public boolean eliminarEmpleado(String codigoEntrada) {
        for (int i = 0; i < contador; i++) {
            if (empleados[i].getCodigoEntrada().equalsIgnoreCase(codigoEntrada)) {
                // mover los elementos restantes una posición hacia arriba
                for (int j = i; j < contador - 1; j++) {
                    empleados[j] = empleados[j + 1];
                }
                empleados[contador - 1] = null;
                contador--;
                return true;
            }
        }
        return false; // No encontrado
    }
    
    public Empleado buscarEmpleado(String codigoEntrada) {
    for (int i = 0; i < contador; i++) {
        if (empleados[i].getCodigoEntrada().equalsIgnoreCase(codigoEntrada)) {
            return empleados[i];
        }
    }
    return null;
}

    public boolean existeCodigo(String codigoEntrada) {
    return buscarEmpleado(codigoEntrada) != null;
}

    public boolean actualizarEmpleado(Empleado actualizado) {
    for (int i = 0; i < contador; i++) {
        if (empleados[i].getCodigoEntrada().equalsIgnoreCase(actualizado.getCodigoEntrada())) {
            empleados[i] = actualizado;
            return true;
        }
    }
    return false;
}
}
