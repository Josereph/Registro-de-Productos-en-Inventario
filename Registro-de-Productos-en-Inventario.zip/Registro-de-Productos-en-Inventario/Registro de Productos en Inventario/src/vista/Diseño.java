package vista;

import clases.Empleado;
import clases.GestionEmpleados;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Diseño extends javax.swing.JFrame {
GestionEmpleados gestion = new GestionEmpleados();
private boolean modoEdicion = false;
private int filaEditando = -1;

    public Diseño() {
        initComponents();
        setLocationRelativeTo(null);
        SpinnerNumberModel modelo = new SpinnerNumberModel(1,1,10000,1);
        spinnerCantidad.setModel(modelo); //Cantidad
        javax.swing.ButtonGroup grupoGenero = new javax.swing.ButtonGroup();
        grupoGenero.add(checkBuenEstado); // Buen Estado
        grupoGenero.add(checkDanado); // Dañado
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        dgvregistro = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        txtCodigoEntrada = new javax.swing.JTextField();
        txtNombreProducto = new javax.swing.JTextField();
        txtObservaciones = new javax.swing.JTextField();
        spinnerCantidad = new javax.swing.JSpinner();
        checkBuenEstado = new javax.swing.JRadioButton();
        checkDanado = new javax.swing.JRadioButton();
        comboUnidadMedida = new javax.swing.JComboBox<>();
        txtLote = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtFecha = new com.toedter.calendar.JDateChooser();
        jScrollPane3 = new javax.swing.JScrollPane();
        listaUbicacion = new javax.swing.JList<>();
        jPanel4 = new javax.swing.JPanel();
        btnguardar = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        btneditar = new javax.swing.JButton();
        btnborrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Registro de Productos en Inventario");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 896, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        dgvregistro.setBackground(new java.awt.Color(255, 255, 255));
        dgvregistro.setForeground(new java.awt.Color(0, 0, 0));
        dgvregistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nombre", "Observaciones", "Cantidad", "Estado", "Unidad de Medidad", "Ubicacion", "Fecha de Registro", "Lote"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        dgvregistro.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                dgvregistroComponentHidden(evt);
            }
        });
        jScrollPane2.setViewportView(dgvregistro);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));

        txtCodigoEntrada.setBackground(new java.awt.Color(255, 255, 255));
        txtCodigoEntrada.setForeground(new java.awt.Color(0, 0, 0));
        txtCodigoEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoEntradaActionPerformed(evt);
            }
        });

        txtNombreProducto.setBackground(new java.awt.Color(255, 255, 255));
        txtNombreProducto.setForeground(new java.awt.Color(0, 0, 0));
        txtNombreProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreProductoActionPerformed(evt);
            }
        });

        txtObservaciones.setBackground(new java.awt.Color(255, 255, 255));
        txtObservaciones.setForeground(new java.awt.Color(0, 0, 0));

        spinnerCantidad.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        checkBuenEstado.setBackground(new java.awt.Color(153, 204, 255));
        checkBuenEstado.setForeground(new java.awt.Color(0, 0, 0));
        checkBuenEstado.setText("Buen estado");
        checkBuenEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBuenEstadoActionPerformed(evt);
            }
        });

        checkDanado.setBackground(new java.awt.Color(153, 204, 255));
        checkDanado.setForeground(new java.awt.Color(0, 0, 0));
        checkDanado.setText("Dañado");

        comboUnidadMedida.setBackground(new java.awt.Color(255, 255, 255));
        comboUnidadMedida.setForeground(new java.awt.Color(0, 0, 0));
        comboUnidadMedida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Unidad", "Pieza", "Ítem", "Caja", "Gramo", "Kilogramo", "Tonelada", "Libra", "Onza", "Mililitro", "Litro", "Galón", "Barril", "Centímetro cúbico", "Metro cúbico", "Milímetro", "Centímetro", "Metro", "Kilómetro", "Pulgada", "Pie", "Yarda", "Metro lineal", "Rollo", "Paquete", "Bolsa", "Saco", "Pallet", "Tarima", "Tambor", "Unidad internacional", "Docena", "Media docena", "Set", "Kit", "Tableta", "Cápsula", "Quintal", "Arroba" }));

        txtLote.setBackground(new java.awt.Color(255, 255, 255));
        txtLote.setForeground(new java.awt.Color(0, 0, 0));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Código de Entrada");

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Nombre de Producto:");

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Observaciones:");

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Estado:");

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Cantidad:");

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Unidad de Medida:");

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Ubicación de Almacenamiento:");

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Fecha de Recibido:");

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("N° Lote:");

        txtFecha.setBackground(new java.awt.Color(255, 255, 255));
        txtFecha.setForeground(new java.awt.Color(0, 0, 0));

        listaUbicacion.setBackground(new java.awt.Color(255, 255, 255));
        listaUbicacion.setForeground(new java.awt.Color(0, 0, 0));
        listaUbicacion.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Bodega Principal", "Bodega Secundaria", "Bodega de Retiro", "Bodega de Cuarentena", "Bodega de Devoluciones", "Bodega de Materia Prima", "Bodega de Producto Terminado" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listaUbicacion);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtFecha, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtNombreProducto, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                    .addComponent(txtCodigoEntrada, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                    .addComponent(spinnerCantidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(checkBuenEstado)
                        .addGap(18, 18, 18)
                        .addComponent(checkDanado))
                    .addComponent(comboUnidadMedida, javax.swing.GroupLayout.Alignment.LEADING, 0, 215, Short.MAX_VALUE)
                    .addComponent(txtLote))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtObservaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtObservaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(txtCodigoEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addGap(7, 7, 7)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(txtNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(spinnerCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(checkBuenEstado)
                                    .addComponent(jLabel5)
                                    .addComponent(checkDanado))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(comboUnidadMedida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(txtLote, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18))
        );

        jPanel4.setBackground(new java.awt.Color(153, 204, 255));

        btnguardar.setBackground(new java.awt.Color(255, 255, 255));
        btnguardar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btnguardar.setForeground(new java.awt.Color(0, 0, 0));
        btnguardar.setText("Guardar");
        btnguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarActionPerformed(evt);
            }
        });

        btnlimpiar.setBackground(new java.awt.Color(255, 255, 255));
        btnlimpiar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btnlimpiar.setForeground(new java.awt.Color(0, 0, 0));
        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });

        btneditar.setBackground(new java.awt.Color(255, 255, 255));
        btneditar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btneditar.setForeground(new java.awt.Color(0, 0, 0));
        btneditar.setText("Editar");
        btneditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditarActionPerformed(evt);
            }
        });

        btnborrar.setBackground(new java.awt.Color(255, 255, 255));
        btnborrar.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        btnborrar.setForeground(new java.awt.Color(0, 0, 0));
        btnborrar.setText("Borrar");
        btnborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnborrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(btnguardar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnlimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btneditar, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnborrar, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnguardar, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(btnlimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnborrar, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(btneditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private boolean actualizarEmpleadoEnGestion(String codigo, String nombre, String observaciones, int cantidad, 
                                           String estado, String unidadMedida, String ubicacion, 
                                           String fechaRecibido, String lote) {
    try {
        int loteNum = Integer.parseInt(lote);
        Empleado actualizado = new Empleado(
                codigo, nombre, estado, cantidad, fechaRecibido,
                unidadMedida, loteNum, ubicacion, observaciones
        );
        return gestion.actualizarEmpleado(actualizado);
    } catch (NumberFormatException ex) {
        return false;
    }
}

    private void btnguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarActionPerformed
     try {
        String codigo = txtCodigoEntrada.getText();
        String nombre = txtNombreProducto.getText();
        String observaciones = txtObservaciones.getText();
        int cantidad = (int) spinnerCantidad.getValue();
        String estado = checkBuenEstado.isSelected() ? "Buen Estado" : "Dañado";
        String unidadMedida = comboUnidadMedida.getSelectedItem().toString();
        String ubicacion = listaUbicacion.getSelectedValue();
        String fecha = ((JTextField)txtFecha.getDateEditor().getUiComponent()).getText();
        String lote = txtLote.getText();

        DefaultTableModel modelo = (DefaultTableModel) dgvregistro.getModel();
        
        if (modoEdicion) {
            // Actualizar fila en tabla
            modelo.setValueAt(codigo, filaEditando, 0);
            modelo.setValueAt(nombre, filaEditando, 1);
            modelo.setValueAt(observaciones, filaEditando, 2);
            modelo.setValueAt(cantidad, filaEditando, 3);
            modelo.setValueAt(estado, filaEditando, 4);
            modelo.setValueAt(unidadMedida, filaEditando, 5);
            modelo.setValueAt(ubicacion, filaEditando, 6);
            modelo.setValueAt(fecha, filaEditando, 7);
            modelo.setValueAt(lote, filaEditando, 8);

            if (actualizarEmpleadoEnGestion(codigo, nombre, observaciones, cantidad, estado, unidadMedida, ubicacion, fecha, lote)) {
                JOptionPane.showMessageDialog(this, "Registro actualizado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el registro.");
            }

            modoEdicion = false;
            filaEditando = -1;
            btnguardar.setText("Guardar");

        } else {
            // Insertar nueva fila
            modelo.addRow(new Object[]{codigo, nombre, observaciones, cantidad, estado, unidadMedida, ubicacion, fecha, lote});

            Empleado nuevo = new Empleado(codigo, nombre, estado, cantidad, fecha, unidadMedida,
                                          Integer.parseInt(lote), ubicacion, observaciones);

            if (gestion.agregarEmpleado(nuevo)) {
                JOptionPane.showMessageDialog(this, "Registro guardado correctamente");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el registro");
            }
        }

        limpiarCampos();
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error! Verifique que todos los campos estén llenos correctamente.");
    }
    }//GEN-LAST:event_btnguardarActionPerformed

    private void txtCodigoEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoEntradaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoEntradaActionPerformed

    private void txtNombreProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreProductoActionPerformed

    private void checkBuenEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBuenEstadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkBuenEstadoActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
     limpiarCampos();
    
    // Si estaba en modo edición, salir del modo edición
    if(modoEdicion) {
        modoEdicion = false;
        filaEditando = -1;
        btnguardar.setText("Guardar 📼");
        JOptionPane.showMessageDialog(this, "Modo edición cancelado");
    }
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void btneditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditarActionPerformed
      int filaSeleccionada = dgvregistro.getSelectedRow();
    if (filaSeleccionada < 0) {
        JOptionPane.showMessageDialog(this, "Por favor, selecciona un registro de la tabla para editar.");
        return;
    }

    modoEdicion = true;
    filaEditando = filaSeleccionada;

    // Código
    txtCodigoEntrada.setText(dgvregistro.getValueAt(filaSeleccionada, 0).toString());
    // Nombre
    txtNombreProducto.setText(dgvregistro.getValueAt(filaSeleccionada, 1).toString());
    // Observaciones
    txtObservaciones.setText(dgvregistro.getValueAt(filaSeleccionada, 2).toString());
    // Cantidad
    spinnerCantidad.setValue(Integer.parseInt(dgvregistro.getValueAt(filaSeleccionada, 3).toString()));
    // Estado
    String estado = dgvregistro.getValueAt(filaSeleccionada, 4).toString();
    if ("Buen Estado".equalsIgnoreCase(estado)) {
        checkBuenEstado.setSelected(true);
    } else {
        checkDanado.setSelected(true);
    }
    // Unidad de medida
    comboUnidadMedida.setSelectedItem(dgvregistro.getValueAt(filaSeleccionada, 5).toString());
    // Ubicación (lista)
    String ubicacion = dgvregistro.getValueAt(filaSeleccionada, 6).toString();
    listaUbicacion.setSelectedValue(ubicacion, true);
    // Fecha (JDateChooser: guardaste String; lo reponemos como String en el editor)
    String fecha = dgvregistro.getValueAt(filaSeleccionada, 7).toString();
    ((JTextField) txtFecha.getDateEditor().getUiComponent()).setText(fecha);
    // Lote
    txtLote.setText(dgvregistro.getValueAt(filaSeleccionada, 8).toString());

    btnguardar.setText("Actualizar");
    JOptionPane.showMessageDialog(this, "Registro cargado para edición. Modifica y presiona 'Actualizar'.");

    }//GEN-LAST:event_btneditarActionPerformed

    private void btnborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnborrarActionPerformed
    int filaSeleccionada = dgvregistro.getSelectedRow();
    if (filaSeleccionada < 0) {
        JOptionPane.showMessageDialog(this, "Selecciona un registro para eliminar.");
        return;
    }

    String codigo = dgvregistro.getValueAt(filaSeleccionada, 0).toString();
    int confirmar = JOptionPane.showConfirmDialog(
            this,
            "¿Estás segur@ de eliminar el registro con código " + codigo + "?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
    );

    if (confirmar == JOptionPane.YES_OPTION) {
        boolean eliminado = gestion.eliminarEmpleado(codigo);
        if (eliminado) {
            ((DefaultTableModel) dgvregistro.getModel()).removeRow(filaSeleccionada);
            JOptionPane.showMessageDialog(this, "Registro eliminado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar (no encontrado).");
        }
    }
    }//GEN-LAST:event_btnborrarActionPerformed

    private void dgvregistroComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_dgvregistroComponentHidden
        // TODO add your handling code here:
    }//GEN-LAST:event_dgvregistroComponentHidden

    private void dgvregistro(){
     DefaultTableModel modelo = (DefaultTableModel) dgvregistro.getModel();
    modelo.setRowCount(0);

    Empleado[] lista = gestion.obtenerEmpleados(); // OJO: aquí sí es obtenerEmpleados()

    for (Empleado emp : lista) {
        if (emp == null) continue;
        Object[] fila = {
            emp.getCodigoEntrada(),
            emp.getNombreProducto(),
            emp.getObservaciones(),
            emp.getCantidad(),
            emp.getEstado(),
            emp.getUnidadMedida(),
            emp.getUbicacion(),
            emp.getFechaRecibido(),
            emp.getNLote()
        };
        modelo.addRow(fila);
    }
        }

    private boolean validarCampos(boolean esEdicion) {
    String codigo = txtCodigoEntrada.getText().trim();
    String nombre = txtNombreProducto.getText().trim();
    String lote = txtLote.getText().trim();
    String fecha = ((JTextField) txtFecha.getDateEditor().getUiComponent()).getText().trim();
    String ubicacion = listaUbicacion.getSelectedValue();

    if (codigo.isEmpty() || nombre.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Código y Nombre son obligatorios.");
        return false;
    }
    if (ubicacion == null) {
        JOptionPane.showMessageDialog(this, "Selecciona una ubicación.");
        return false;
    }
    if (fecha.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Selecciona o escribe una fecha válida.");
        return false;
    }
    try { Integer.parseInt(lote); }
    catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El lote debe ser un número entero.");
        return false;
    }

    // Evitar duplicados si es inserción
    if (!esEdicion && gestion.existeCodigo(codigo)) {
        JOptionPane.showMessageDialog(this, "Ya existe un registro con ese código.");
        return false;
    }

    return true;
}

    private void limpiarCampos() {
    txtCodigoEntrada.setText("");
    txtNombreProducto.setText("");
    txtObservaciones.setText("");
    spinnerCantidad.setValue(1);
    checkBuenEstado.setSelected(true);
    comboUnidadMedida.setSelectedIndex(0);
    listaUbicacion.clearSelection();
    ((JTextField) txtFecha.getDateEditor().getUiComponent()).setText("");
    txtLote.setText("");
}

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Diseño.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Diseño().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnborrar;
    private javax.swing.JButton btneditar;
    private javax.swing.JButton btnguardar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JRadioButton checkBuenEstado;
    private javax.swing.JRadioButton checkDanado;
    private javax.swing.JComboBox<String> comboUnidadMedida;
    private javax.swing.JTable dgvregistro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JList<String> listaUbicacion;
    private javax.swing.JSpinner spinnerCantidad;
    private javax.swing.JTextField txtCodigoEntrada;
    private com.toedter.calendar.JDateChooser txtFecha;
    private javax.swing.JTextField txtLote;
    private javax.swing.JTextField txtNombreProducto;
    private javax.swing.JTextField txtObservaciones;
    // End of variables declaration//GEN-END:variables
}
